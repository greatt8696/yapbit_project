import React from "react";

const Main = () => {
  return (
    <div className="flex flex-col w-full h-full p-2">
      <div className="grid grid-cols-2 h-[46%]">
        <div className="m-1 col-span-1 bg-slate-100/30 rounded-3xl p-3">
          
        </div>
        <div className="m-1 col-span-1 bg-slate-100/30 rounded-3xl p-3">
          
        </div>
      </div>
      <div className="grid grid-cols-2 h-[46%]">
        <div className="m-1 col-span-1 bg-slate-100/30 rounded-3xl p-3">
          
        </div>
        <div className="m-1 col-span-1 bg-slate-100/30 rounded-3xl p-3">
          
        </div>
      </div>
    </div>
  );
};

export default Main;
